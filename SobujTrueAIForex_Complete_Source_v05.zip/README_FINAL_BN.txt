Sobuj True AI Forex — consolidated source v0.5

WHAT IS INCLUDED
- Android app project (Kotlin)
- 1-minute Twelve Data candle request for a user-entered Forex symbol
- Feature extraction aligned to the Python training script
- ML inference class that reads a trained model.json asset
- Floating overlay that displays the latest BUY/SELL/WAIT result
- Python training script and chronological holdout evaluation
- GitHub Actions workflow for a debug APK build

IMPORTANT LIMITATIONS
1. No trained model.json is bundled. Run ml/train_model.py with your own Twelve Data key and put the generated file at app/src/main/assets/model.json.
2. The app currently analyzes the latest returned candle. It does not yet guarantee that the candle is closed at the moment of analysis. Do not use for real-money 1-minute expiry until closed-candle timing is implemented and tested.
3. The training script uses a simple logistic regression baseline. This is genuine machine learning, but not evidence of a profitable edge.
4. Only pairs supported by your Twelve Data plan will work. The app takes one symbol per analysis; it does not automatically scan all pairs yet.
5. The API key is entered in the app and used for the request; this prototype does not implement encrypted persistence. Do not publish keys or commit them to GitHub.
6. Debug APK only. Release signing, device QA, rate-limit handling, secure key storage, full walk-forward tests, spread/payout modelling, and automatic all-pair scanning remain future work.

BUILD
- Open project root in Android Studio, or upload all project files to GitHub.
- GitHub Actions > Build Sobuj True AI Forex APK > Run workflow.
- Download artifact SobujTrueAIForex-debug-apk after successful build.
- Install app-debug.apk on Android and grant Display over other apps permission for floating panel.

TRAIN MODEL
- pip install requests pandas numpy scikit-learn
- Set TWELVE_DATA_API_KEY environment variable.
- From ml folder: python train_model.py --symbol EUR/USD --outputsize 5000
- Copy generated model.json into app/src/main/assets/model.json, then rebuild.
- Check held-out metrics; repeat across pairs and time periods. Do not assume confidence is win probability.
