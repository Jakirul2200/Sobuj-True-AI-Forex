Sobuj True AI Forex — ML training pipeline (v0.3)

This adds a real, trainable machine-learning research pipeline:
- downloads 1-minute candles from Twelve Data
- builds eight transparent price/volatility features
- trains logistic regression on earlier data
- evaluates on a later, chronologically held-out test segment
- exports model.json for Android inference

IMPORTANT
- The model is not trained until you run the script with your own API key.
- A single 80/20 split is only an initial check, not proof of an edge.
- It predicts next-candle direction, which may not align with Quotex payout/expiry.
- No profit guarantee; use demo and paper-trade first.
- Check Twelve Data plan/history/rate limits and symbol support.
- API key must stay private. Do not paste it into chat or publish it in source control.

TRAIN
1. Install Python 3.10+.
2. Install dependencies: pip install requests pandas numpy scikit-learn
3. Set environment variable TWELVE_DATA_API_KEY, or pass --apikey.
4. From the ml folder run:
   python train_model.py --symbol EUR/USD --outputsize 5000
5. Inspect test accuracy, balanced accuracy, confusion matrix and sample count.
6. The generated artifact is app/src/main/assets/model.json.
7. Rebuild the Android app after placing the artifact.

Android inference
SignalModel.kt reads model.json and computes BUY/SELL/WAIT probabilities.
The live candle fetch + feature calculation + signal display still needs to be wired into the app.
Do not treat a model score as a win probability until it has been calibrated and validated.

NEXT VALIDATION BEFORE REAL USE
- Walk-forward tests over several non-overlapping date windows
- Test several major pairs separately
- Include spread, payout, latency and expiry assumptions
- Compare with a no-trade baseline
- Record every signal and outcome
- Keep WAIT when data is stale, candle is incomplete, or model artifact is missing
