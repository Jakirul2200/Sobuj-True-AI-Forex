package com.sobuj.trueai

import android.content.Context
import org.json.JSONObject
import kotlin.math.exp

/**
 * Reads a model.json exported by ml/train_model.py.
 * Returns calibrated probabilities only after a real trained artifact is supplied.
 */
class SignalModel(private val context: Context) {
    data class Result(val label: String, val probabilityUp: Double, val confidence: Int)

    private val model: JSONObject by lazy {
        context.assets.open("model.json").bufferedReader().use { JSONObject(it.readText()) }
    }

    fun predict(features: DoubleArray): Result {
        require(features.size == 8) { "Expected 8 features" }
        val means = model.getJSONArray("mean")
        val scales = model.getJSONArray("scale")
        val coefs = model.getJSONArray("coef")
        var z = model.getDouble("intercept")
        for (i in features.indices) {
            val scale = scales.getDouble(i).let { if (it == 0.0) 1.0 else it }
            val normalized = (features[i] - means.getDouble(i)) / scale
            z += normalized * coefs.getDouble(i)
        }
        val pUp = 1.0 / (1.0 + exp(-z))
        val buy = model.getJSONObject("thresholds").getDouble("buy")
        val sell = model.getJSONObject("thresholds").getDouble("sell")
        val label = when {
            pUp >= buy -> "BUY"
            pUp <= sell -> "SELL"
            else -> "WAIT"
        }
        val confidence = (maxOf(pUp, 1.0 - pUp) * 100).toInt()
        return Result(label, pUp, confidence)
    }
}
