package com.sobuj.trueai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class FloatingSignalService : Service() {
    private var wm: WindowManager? = null
    private var panel: TextView? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(7, buildNotification())
        val signal = intent?.getStringExtra("signal") ?: "WAIT"
        val detail = intent?.getStringExtra("detail") ?: "সিগন্যাল বিশ্লেষণ করুন"
        val content = "SOBUJ TRUE AI • 1M\\n$signal\\n$detail"
        if (panel == null) addPanel(content) else panel?.text = content
        return START_STICKY
    }

    private fun addPanel(content: String) {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = TextView(this).apply {
            text = content
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(20, 16, 20, 16)
            setBackgroundColor(Color.rgb(20, 35, 45))
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 160 }
        wm?.addView(view, params)
        panel = view
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel("sobuj_signal", "Sobuj Forex Signal", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, "sobuj_signal").setContentTitle("Sobuj True AI Forex")
                .setContentText("Floating signal panel সক্রিয়").setSmallIcon(android.R.drawable.ic_dialog_info).build()
        else @Suppress("DEPRECATION") Notification.Builder(this)
            .setContentTitle("Sobuj True AI Forex").setContentText("Floating signal panel সক্রিয়")
            .setSmallIcon(android.R.drawable.ic_dialog_info).build()

    override fun onDestroy() { panel?.let { wm?.removeView(it) }; panel = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
