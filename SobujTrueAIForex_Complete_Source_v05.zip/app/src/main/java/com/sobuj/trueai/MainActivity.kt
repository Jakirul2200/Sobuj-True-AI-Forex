package com.sobuj.trueai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import kotlin.math.sqrt

class MainActivity : Activity() {
    private lateinit var apiKey: EditText
    private lateinit var pairInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        apiKey = findViewById(R.id.apiKey)
        pairInput = findViewById(R.id.symbol)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.testButton).setOnClickListener { analyze() }
        findViewById<Button>(R.id.overlayButton).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Display over other apps অনুমতি দিন", Toast.LENGTH_LONG).show()
            } else {
                val i = Intent(this, FloatingSignalService::class.java)
                    .putExtra("signal", "WAIT")
                    .putExtra("detail", "প্রথমে Analyze চাপুন")
                startForegroundService(i)
            }
        }
    }

    private fun analyze() {
        val key = apiKey.text.toString().trim()
        val pair = pairInput.text.toString().trim().ifBlank { "EUR/USD" }
        if (key.isBlank()) { status.text = "Twelve Data API Key দিন। এটি কাউকে পাঠাবেন না।"; return }
        status.text = "লাইভ 1-minute candles সংগ্রহ করা হচ্ছে..."
        thread {
            val output = try {
                val encodedPair = java.net.URLEncoder.encode(pair, "UTF-8")
                val encodedKey = java.net.URLEncoder.encode(key, "UTF-8")
                val url = URL("https://api.twelvedata.com/time_series?symbol=$encodedPair&interval=1min&outputsize=80&apikey=$encodedKey&format=JSON&timezone=UTC")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000; readTimeout = 15000; requestMethod = "GET"
                }
                val body = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream)
                    .bufferedReader().use { it.readText() }
                conn.disconnect()
                val root = JSONObject(body)
                if (root.optString("status") == "error") throw IllegalStateException(root.optString("message", "API error"))
                val arr = root.optJSONArray("values") ?: throw IllegalStateException("এই pair-এর candle data পাওয়া যায়নি")
                if (arr.length() < 30) throw IllegalStateException("পর্যাপ্ত candle নেই: অন্তত 30টি দরকার")
                // Twelve Data returns newest first. Reverse to chronological order.
                val rows = (0 until arr.length()).map { arr.getJSONObject(it) }.reversed()
                val closes = rows.map { it.getString("close").toDouble() }
                val opens = rows.map { it.getString("open").toDouble() }
                val highs = rows.map { it.getString("high").toDouble() }
                val lows = rows.map { it.getString("low").toDouble() }
                val f = buildFeatures(opens, highs, lows, closes)
                val modelResult = try {
                    SignalModel(this).predict(f)
                } catch (_: Exception) {
                    null
                }
                if (modelResult == null) {
                    "ডেটা সংযোগ সফল: $pair\\nশেষ candle: ${rows.last().optString("datetime")}\\nClose: ${closes.last()}\\n\\nAI মডেল পাওয়া যায়নি। আগে ml/train_model.py চালিয়ে model.json তৈরি করে app/src/main/assets/ এ রাখতে হবে।\\nসিগন্যাল: WAIT"
                } else {
                    "Pair: $pair\\nTimeframe: 1 Minute\\nশেষ candle: ${rows.last().optString("datetime")}\\nClose: ${closes.last()}\\nAI signal: ${modelResult.label}\\nModel score: ${modelResult.confidence}% (জয়ের সম্ভাবনা নয়)"
                }
            } catch (e: Exception) {
                "বিশ্লেষণ ব্যর্থ: ${e.message ?: "Network/API error"}"
            }
            runOnUiThread {
                status.text = output
                val signal = when {
                    output.contains("AI signal: BUY") -> "BUY"
                    output.contains("AI signal: SELL") -> "SELL"
                    else -> "WAIT"
                }
                val detail = output.lines().take(5).joinToString("\\n")
                if (Settings.canDrawOverlays(this)) {
                    startForegroundService(Intent(this, FloatingSignalService::class.java)
                        .putExtra("signal", signal).putExtra("detail", detail))
                }
            }
        }
    }

    // Feature order exactly matches ml/train_model.py:
    // ret1, ret3, ret5, ema_gap, rsi14, range_pct, body_pct, volatility10
    private fun buildFeatures(o: List<Double>, h: List<Double>, l: List<Double>, c: List<Double>): DoubleArray {
        fun ema(values: List<Double>, period: Int): List<Double> {
            val alpha = 2.0 / (period + 1.0)
            val out = mutableListOf<Double>()
            values.forEachIndexed { i, v -> out.add(if (i == 0) v else alpha * v + (1 - alpha) * out[i - 1]) }
            return out
        }
        val last = c.last()
        val ret1 = last / c[c.size - 2] - 1.0
        val ret3 = last / c[c.size - 4] - 1.0
        val ret5 = last / c[c.size - 6] - 1.0
        val ef = ema(c, 8).last()
        val es = ema(c, 21).last()
        val emaGap = (ef - es) / last

        var avgGain = 0.0; var avgLoss = 0.0
        val start = (c.size - 15).coerceAtLeast(1)
        for (i in start until c.size) {
            val d = c[i] - c[i - 1]
            val gain = maxOf(d, 0.0); val loss = maxOf(-d, 0.0)
            if (i == start) { avgGain = gain; avgLoss = loss }
            else { avgGain = (avgGain * 13 + gain) / 14; avgLoss = (avgLoss * 13 + loss) / 14 }
        }
        val rsi = if (avgLoss == 0.0) 1.0 else (1.0 - 1.0 / (1.0 + avgGain / avgLoss))
        val rangePct = (h.last() - l.last()) / last
        val bodyPct = (c.last() - o.last()) / last
        val returns = (1 until c.size).map { c[it] / c[it - 1] - 1.0 }.takeLast(10)
        val mean = returns.average()
        val vol = sqrt(returns.map { (it - mean) * (it - mean) }.average())
        return doubleArrayOf(ret1, ret3, ret5, emaGap, rsi, rangePct, bodyPct, vol)
    }
}
