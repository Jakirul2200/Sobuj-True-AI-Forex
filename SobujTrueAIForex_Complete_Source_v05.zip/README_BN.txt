Sobuj True AI Forex — Android starter v0.2

এই আপডেটে Twelve Data থেকে 1-minute candle আনার প্রাথমিক সংযোগ-পরীক্ষা যোগ করা হয়েছে।
ব্যবহার:
1. Android Studio-তে project folder খুলুন।
2. Gradle sync করুন এবং Android SDK 35 ব্যবহার করুন।
3. ফোনে Run/Install করুন।
4. নিজের Twelve Data API key অ্যাপের মধ্যে দিন (চ্যাটে পাঠাবেন না)।
5. EUR/USD বা অন্য supported symbol দিয়ে 'লাইভ 1M ডেটা পরীক্ষা' চাপুন।
6. Overlay চালু করতে 'Floating Window' চাপুন এবং Android permission দিন।

সীমাবদ্ধতা:
- এটি এখনো trained AI/ML signal engine নয়।
- API plan, symbol availability, rate limit এবং internet-এর ওপর ডেটা নির্ভর করে।
- সব পেয়ার API-তে সমর্থিত নাও হতে পারে।
- Floating overlay বর্তমানে WAIT/placeholder দেখায়; live signal feed যুক্ত হয়নি।
- Production APK signing, secure key storage, ML training, walk-forward validation এবং device testing বাকি।
- ডেমো/ব্যাকটেস্টের আগে real-money trade করবেন না।
